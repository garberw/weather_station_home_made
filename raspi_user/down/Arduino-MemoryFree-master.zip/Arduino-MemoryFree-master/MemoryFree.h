// memoryFree header
// From http://www.arduino.cc/cgi-bin/yabb2/YaBB.pl?num=1213583720/15
// ...written by user "mem".

#ifndef	MEMORY_FREE_H
#define MEMORY_FREE_H

int freeMemory();

#endif
